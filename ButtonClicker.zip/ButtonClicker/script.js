
function login(element) {
    if (element.innerText == "Login") {
        element.innerText = "Logout"; 
    } else {
        element.innerText = "Login"; 
    }
}

function remove(element) {
    element.remove();
}

function showAlert() {
    element.showAlert ("this page says Ninja was Liked "); 
}


function print(x) {
    console.log(x)

}

