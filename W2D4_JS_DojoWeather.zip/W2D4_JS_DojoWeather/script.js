
function removeWarning() {
    const element = document.getElementById("warning");
    element.remove();
}

function displayAlert() {
    alert("loading weather report"); 
}

