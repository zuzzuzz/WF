var count = 1; 
var countElement = document.querySelector("#count"); 


function add1() {
    count++; 
    countElement.innerText = "like(s) " + count;
}

function add2() {
    count++; 
    countElement.innerText = "like(s) " + count;
}

function add3() {
    count++; 
    countElement.innerText = "like(s) " + count;
}

// function subtract1 (){
//     count --; 
//     countElement.innerText = "the count is " + count; 
// }